# ybw's Package

## The packge include 2 parts now

- abbreviation
- bin tools

### abbrevation

- `cv2.imshow()` -> `im_show()`
- `os.mkdir()` -> `mkdir()`
- `os.mkdirs()` -> `mkdirs()`
- `os.path.join` -> `j`

    各个函数都进行了人性化的改动，调用更加便捷。

### bin tools

- `sb`类(`string` & `bytearray`)

    拥有.str和.btar两个属性，方便操作

- abc：小写字母
- ABC：大写字母
- chSet：range(32,128)
- `Xor`函数：对两个bytes串进行异或
